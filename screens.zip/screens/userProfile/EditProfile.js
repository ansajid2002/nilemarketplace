import React, { useEffect, useState } from 'react';
import {
    View,
    Text,
    TouchableOpacity,
    Image,
    TextInput,
    ScrollView,
    Alert,
    Modal,
    Button,
} from 'react-native';
import Ionic from 'react-native-vector-icons/Ionicons';
import { AdminUrl } from '../../constant';
import { updateCustomerData } from '../../store/slices/customerData';
import { useDispatch } from 'react-redux';
import FullPageLoader from '../../components/FullPageLoader';
import { debounce, isEqual } from 'lodash';
import * as ImagePicker from "expo-image-picker"
import { AntDesign, MaterialIcons, Feather } from '@expo/vector-icons';
import { useTranslation } from 'react-i18next';
import { SafeAreaView } from 'react-native';
import { Colors } from '../../constants/styles';

const EditProfile = ({ route, navigation }) => {
    const { given_name, family_name, email, bio, phone_number, verified_with, picture, google_id, customer_id } = route.params?.[0];
    const dispatch = useDispatch()
    const { t } = useTranslation()
    // State to manage the user profile
    const [userProfile, setUserProfile] = useState({
        given_name,
        family_name,
        email,
        bio,
        phone_number
    });

    // State to manage the OTP modal visibility
    const [isOTPModalVisible, setOTPModalVisible] = useState(false);

    // State to manage OTP input
    const [otpInput, setOtpInput] = useState('');
    const [loader, setloader] = useState(false);
    const [originalUserProfile, setOriginalUserProfile] = useState({ ...userProfile });
    const [formValueChanged, setFormValueChanged] = useState(false);
    const [image, setImage] = useState('https://www.sfb1425.uni-freiburg.de/wp-content/uploads/2021/05/dummy-profile-pic-360x360.png');
    const [modalVisible, setModalVisible] = useState(false);
    const [imageOptions] = useState([
        { label: <AntDesign name="camera" size={24} color="white" />, value: 'camera' },
        { label: <MaterialIcons name="perm-media" size={24} color="white" />, value: 'gallery' },
        // { label: <Feather name="trash" size={24} color="white" />, value: 'remove' },
    ]);

    useEffect(() => {
        // Compare the current form values with the original values
        const hasFormValueChanged = !isEqual(userProfile, originalUserProfile);

        // Enable or disable the "ProfileSubmit" button accordingly
        setFormValueChanged(hasFormValueChanged);
    }, [userProfile, originalUserProfile]);

    // Updated image URL logic
    useEffect(() => {
        if (!google_id && picture) {
            setImage(`${AdminUrl}/uploads/customerProfileImages/${picture}`)
        } else if (picture) {
            setImage(picture)
        }
    }, [])

    const handleProfileChange = (field, value) => {
        setUserProfile({
            ...userProfile,
            [field]: value,
        });
        // Mark that the form values have changed
        setFormValueChanged(true);
    };

    const handleProfileSubmit = async () => {
        setOtpInput('')
        setloader(true)
        // Check if required fields are empty
        if (!userProfile.given_name || !userProfile.family_name || !userProfile.email || !userProfile.phone_number) {
            Alert.alert('Error', 'Please fill in all required fields');
            return;
        }

        // Validate email format
        const emailPattern = /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i;
        if (!emailPattern.test(userProfile.email)) {
            Alert.alert('Error', 'Please enter a valid email address');
            return;
        }

        try {
            const response = await fetch(`${AdminUrl}/api/AppUserProfileOTP`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    email: userProfile.email,
                    family_name: userProfile.family_name,
                    given_name: userProfile.given_name,
                    customer_id,
                }),
            });

            if (response.ok) {
                // Request was successful
                // Show a success message
                // Open the OTP modal here
                setOTPModalVisible(true);
            } else {
                // Request failed
                // Handle the error based on the response status code
                if (response.status === 400) {
                    // Handle specific error, such as duplicate email
                    Alert.alert('Error', 'Email already registered');
                } else {
                    // Handle other errors
                    throw new Error('Failed to send OTP. Please try again.');
                }
            }
            setloader(false)

        } catch (error) {
            // Handle any exceptions or network errors
            Alert.alert('Error', error.message);
        }

    };

    const handleOTPVerification = async () => {
        // Check if OTP is a 4-digit number
        if (/^\d{4}$/.test(otpInput)) {
            // OTP is valid, proceed with sending it to the backend

            try {
                const response = await fetch(`${AdminUrl}/api/EditProfileAfterVerification`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        otp: otpInput, // Send the OTP to the backend
                        customer_id,
                        userProfile: userProfile, // Send the userProfile data
                    }),
                });

                if (response.ok) {
                    // Request was successful, handle success response
                    // For example, you can show a success message
                    const data = await response.json()
                    dispatch(updateCustomerData(data?.updatedProfile))
                    setOTPModalVisible(false); // Close the OTP modal
                    navigation.goBack()

                } else {
                    // Request failed, handle the error
                    throw new Error('Failed to verify OTP. Please try again.');
                }
            } catch (error) {
                // Handle any exceptions or network errors
                Alert.alert('Error', error.message);
            }
        } else {
            // OTP is not a 4-digit number, show an error message
            Alert.alert('Error', 'Please enter a 4-digit OTP code.');
        }
    };

    const uploadImage = async (mode) => {
        try {
            let result;
            if (mode === "gallery") {
                await ImagePicker.requestMediaLibraryPermissionsAsync();
                result = await ImagePicker.launchImageLibraryAsync({
                    mediaTypes: ImagePicker.MediaTypeOptions.Images,
                    allowsEditing: true,
                    aspect: [1, 1],
                    quality: 1,
                });
            } else {
                await ImagePicker.requestCameraPermissionsAsync();
                result = await ImagePicker.launchCameraAsync({
                    allowsEditing: true,
                    aspect: [1, 1],
                    quality: 1,
                });
            }

            if (!result.canceled) {
                const formData = new FormData();
                formData.append('picture', {
                    uri: result.assets[0].uri,
                    type: 'image/jpeg', // Adjust the type based on the image type
                    name: 'image.jpg', // Adjust the name as needed
                });
                formData.append("key", customer_id);

                const response = await fetch(`${AdminUrl}/api/uploadCustomerProfileImage`, {
                    method: 'POST',
                    body: formData,
                    headers: {
                        'Content-Type': 'multipart/form-data',
                    },
                });

                if (response.ok) {
                    // Image upload was successful
                    const data = await response.json();
                    setImage(`${AdminUrl}/uploads/customerProfileImages/${data?.picture}`)
                    dispatch(updateCustomerData(data?.updatedRows[0]))
                } else {
                    // Handle upload failure
                    console.error('Image upload failed');
                }
                setModalVisible(false)
            }
        } catch (error) {
            console.log(error);
        }
    };

    return (
        !loader ?
        <SafeAreaView style={{ flex: 1, backgroundColor: Colors.whiteColor }} className="">

                <ScrollView>
                    <View style={{ flex: 1, backgroundColor: 'white' }}>
                        <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: 10 }}>
                            <TouchableOpacity onPress={() => navigation.goBack()}>
                                <Ionic name="close-outline" style={{ fontSize: 35 }} />
                            </TouchableOpacity>
                            <Text style={{ fontSize: 16, fontWeight: 'bold' }}>{t("Edit Profile")}</Text>
                            <TouchableOpacity
                                onPress={debounce(() => handleProfileSubmit(), 500)}
                                disabled={!formValueChanged}
                            >
                                <Ionic name="checkmark" style={{ fontSize: 35, color: formValueChanged ? '#3493D9' : 'gray' }} />
                            </TouchableOpacity>
                        </View>
                        <TouchableOpacity onPress={debounce(() => setModalVisible(true), 500)}>
                            <View style={{ padding: 20, alignItems: 'center' }}>
                                <Image resizeMode='contain' source={{ uri: image }} style={{ width: 80, height: 80, borderRadius: 100 }} />
                                <Text style={{ color: '#3493D9' }}>{t("Change profile photo")}</Text>
                            </View>
                        </TouchableOpacity>
                        <View style={{ padding: 10 }}>
                            <InputField label="First Name *" placeholder="First Name" value={userProfile.given_name} onChangeText={(text) => handleProfileChange('given_name', text)} />
                            <InputField label="Last Name *" placeholder="Last Name" value={userProfile.family_name} onChangeText={(text) => handleProfileChange('family_name', text)} />
                            <InputField label="Bio" placeholder="Bio" value={userProfile.bio} onChangeText={(text) => handleProfileChange('bio', text)} />
                            <InputField label="Email *" placeholder="Email" value={userProfile.email} onChangeText={(text) => handleProfileChange('email', text)} />
                            <InputField label="Mobile Number *" placeholder="Mobile Number with Country Code" value={userProfile.phone_number} onChangeText={(text) => handleProfileChange('phone_number', text)} />
                        </View>
                    </View>

                    {/* OTP Modal */}
                    <Modal
                        visible={isOTPModalVisible}
                        transparent={true}
                        animationType="slide">
                        <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: 'rgba(0, 0, 0, 0.7)' }}>
                            <View style={{ backgroundColor: 'white', padding: 15, borderRadius: 10, width: 250 }} >
                                <Text className="font-bold text-xl text-gray-700">Enter OTP</Text>
                                <Text className="text-sm text-gray-700 mb-5">A verification code has been sent to your email.</Text>
                                <TextInput
                                    placeholder="Enter OTP"
                                    value={otpInput}
                                    onChangeText={(text) => setOtpInput(text)}
                                    style={{ fontSize: 16, borderBottomWidth: 1, borderColor: '#CDCDCD', marginBottom: 10 }}
                                />
                                <View className="flex-row w-1/2">
                                    <TouchableOpacity onPress={debounce(() => setOTPModalVisible(false), 500)} className="flex-row justify-center w-full">
                                        <Text style={{ fontSize: 16, color: '#313131' }}>Cancel</Text>
                                    </TouchableOpacity>
                                    <TouchableOpacity onPress={debounce(() => handleOTPVerification(), 500)} className="flex-row justify-center w-full">
                                        <Text style={{ fontSize: 16, color: '#3493D9' }}>Verify</Text>
                                    </TouchableOpacity>
                                </View>
                            </View>
                        </View>
                    </Modal>

                    <Modal
                        animationType="slide"
                        transparent={true}
                        visible={modalVisible}
                        onRequestClose={() => setModalVisible(false)}
                    >
                        <View className="flex-1 justify-center items-center bg-black/40">
                            <View className="space-x-6  bg-white rounded-md flex-row justify-center items-center h-18 p-4">
                                {imageOptions.map((option) => {
                                    return (
                                        <TouchableOpacity
                                            key={option.value}
                                            onPress={debounce(() => {
                                                uploadImage(option.value);
                                            }, 500)}
                                            className='p-2  bg-blue-400 rounded text-white'
                                        >
                                            <Text className='text-center'>{option.label}</Text>
                                            <Text className='text-center capitalize mt-1 text-white'>{option.value}</Text>
                                        </TouchableOpacity>
                                    );
                                })}

                            </View>
                            <TouchableOpacity className="mt-4" onPress={debounce(() => setModalVisible(false), 500)}>
                                <AntDesign name="close" size={24} color="black" />
                            </TouchableOpacity>

                        </View>
                    </Modal>
                </ScrollView>
            </SafeAreaView> : <FullPageLoader />
    );
};

const InputField = ({ label, placeholder, value, onChangeText }) => {
    return (
        <View style={{ paddingVertical: 10 }}>
            <Text style={{ opacity: 0.5 }}>{label}</Text>
            <TextInput
                placeholder={placeholder}
                value={value}
                onChangeText={onChangeText}
                style={{ fontSize: 16, borderBottomWidth: 1, borderColor: '#CDCDCD' }}
            />
        </View>
    );
};

export default EditProfile;
